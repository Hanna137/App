package com.example.apptravel.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class TeamMember(
    val name: String,
    val studentId: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen() {
    val teamMembers = listOf(
        TeamMember("Nguyễn Thị Kim Anh", "22166003"),
        TeamMember("Nguyễn Trần Thu Hằng", "22166022"),
        TeamMember("Lê Đặng Ngọc Hiếu", "22166024"),
        TeamMember("Trần Nhật Huyền My", "22166054"),
        TeamMember("Nguyễn Lê Du Na", "22166055"),
        TeamMember("Nguyễn Thị Ngọc", "22166059"),
        TeamMember("Nguyễn Nhã Trúc", "22166092")
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GIỚI THIỆU NHÓM") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "Lập trình GIS trên thiết bị di động ",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                Text(
                    text = "Danh sách các thành viên trong nhóm:",
                    fontSize = 16.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            items(teamMembers) { member ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F1F1)),
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(40.dp)
                                .padding(end = 16.dp)
                        )

                        Column {
                            Text(
                                text = member.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "MSSV: ${member.studentId}",
                                fontSize = 14.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
