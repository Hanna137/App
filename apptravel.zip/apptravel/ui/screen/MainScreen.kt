package com.example.apptravel.ui

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.preference.PreferenceManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.navigation.NavController
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

fun loadGeoJsonAndDisplayPoints(
    map: MapView,
    context: Context,
    filterType: String = "all",
    onMarkerClick: (title: String, description: String) -> Unit
) {
    map.overlays.removeIf { it !is MyLocationNewOverlay }

    val filenames = if (filterType == "all") {
        listOf("cultural.geojson", "entertainment.geojson", "food.geojson", "hotel.geojson", "temple.geojson", "transport.geojson")
    } else {
        listOf("$filterType.geojson")
    }

    for (filename in filenames) {
        val jsonStr = context.assets.open(filename).bufferedReader().use { it.readText() }
        val json = JSONObject(jsonStr)
        val features = json.getJSONArray("features")

        for (i in 0 until features.length()) {
            val feature = features.getJSONObject(i)
            val geometry = feature.getJSONObject("geometry")
            val type = geometry.getString("type")

            if (type == "Point") {
                val coords = geometry.getJSONArray("coordinates")
                val lon = coords.getDouble(0)
                val lat = coords.getDouble(1)
                val properties = feature.optJSONObject("properties") ?: JSONObject()
                val name = properties.optString("name", "Điểm không tên")
                val description = properties.optString("description", "Không có mô tả")

                val marker = Marker(map)  /// Tạo marker
                marker.position = GeoPoint(lat, lon)
                marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                marker.title = name

                marker.setOnMarkerClickListener { _, _ ->
                    onMarkerClick(name, description)
                    true
                }

                map.overlays.add(marker)
            }
        }
    }

    map.invalidate()
}

@Composable
fun MainScreen(navController: NavController) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf("all") }
    var mapView by remember { mutableStateOf<MapView?>(null) }
    var myLocationOverlay by remember { mutableStateOf<MyLocationNewOverlay?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var dialogContent by remember { mutableStateOf("") }
    var lastClickedButton by remember { mutableStateOf("all") }
///Yêu cầu truy cập GPS
    LaunchedEffect(Unit) {
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                context as Activity,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1001
            )
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = {
                Configuration.getInstance().load(
                    context,
                    PreferenceManager.getDefaultSharedPreferences(context)
                )

                val map = MapView(context)
                map.setTileSource(TileSourceFactory.MAPNIK)
                map.setMultiTouchControls(true)
                map.controller.setZoom(6.0)
                map.controller.setCenter(GeoPoint(21.03, 105.85))

                mapView = map

                loadGeoJsonAndDisplayPoints(map, context, selectedType) { title, description ->
                    dialogContent = "$title\n\n$description"
                    showDialog = true
                }

                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    val overlay = MyLocationNewOverlay(GpsMyLocationProvider(context), map)
                    overlay.enableMyLocation()
                    overlay.enableFollowLocation()
                    map.overlays.add(overlay)
                    myLocationOverlay = overlay
                }

                map
            }
        )

        val types = listOf(
            "Tất cả",
            "Bảo tàng, di tích",
            "Giải trí",
            "Ẩm thực",
            "Khách sạn",
            "Chùa, nhà thờ",
            "Giao thông"
        )
        val typeToFileMap = mapOf(
            "Tất cả" to "all",
            "Bảo tàng, di tích" to "cultural",
            "Giải trí" to "entertainment",
            "Ẩm thực" to "food",
            "Khách sạn" to "hotel",
            "Chùa, nhà thờ" to "temple",
            "Giao thông" to "transport"
        )

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(types) { type ->
                val fileType = typeToFileMap[type] ?: "all"
                val isSelected = lastClickedButton == fileType

                Button(
                    onClick = {
                        selectedType = fileType
                        lastClickedButton = fileType
                        mapView?.let {
                            loadGeoJsonAndDisplayPoints(it, context, selectedType) { title, description ->
                                dialogContent = "$title\n\n$description"
                                showDialog = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
                    ),
                    modifier = Modifier.height(40.dp)
                ) {
                    Text(
                        text = type,
                        style = if (isSelected) {
                            MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        } else {
                            MaterialTheme.typography.bodyMedium
                        }
                    )
                }
            }
        }

        Button(
            onClick = {
                lastClickedButton = "locate"
                val myLoc = myLocationOverlay?.myLocation
                if (myLoc != null) {
                    mapView?.controller?.setZoom(16.0)
                    mapView?.controller?.animateTo(myLoc)
                } else {
                    Toast.makeText(context, "Không xác định được vị trí", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (lastClickedButton == "locate") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
            ),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            Text("Định vị lại")
        }

        Button(
            onClick = {
                lastClickedButton = "about"
                navController.navigate("about")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = if (lastClickedButton == "about") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer
            ),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text("Giới thiệu nhóm")
        }
/// Chứa thông tin hộp thoại địa điểm, chuyển tên ảnh
        if (showDialog) {
            val firstLine = dialogContent.lines().firstOrNull().orEmpty()
            val normalized = java.text.Normalizer.normalize(firstLine, java.text.Normalizer.Form.NFD)
                .replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
                .replace('đ', 'd')
                .replace('Đ', 'D')
            val imageName = normalized
                .lowercase()
                .replace("\\s+".toRegex(), "")
                .replaceFirstChar { it.uppercase() } + ".jpg"

            AlertDialog(
                onDismissRequest = { showDialog = false },
                confirmButton = {
                    Button(onClick = { showDialog = false }) {
                        Text("Đóng")
                    }
                },
                title = { Text("Thông tin địa điểm") },
                text = {
                    Column {
                        Text(dialogContent)
                        Spacer(modifier = Modifier.height(8.dp))
                        LoadImageFromAssets(imageName)
                    }
                }
            )
        }
    }
}

@SuppressLint("RememberReturnType")
@Composable
fun LoadImageFromAssets(imageName: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val imageBitmap = remember(imageName) {
        try {
            val inputStream = context.assets.open("images/$imageName")
            BitmapFactory.decodeStream(inputStream)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    if (imageBitmap != null) {
        Image(
            bitmap = imageBitmap,
            contentDescription = null,
            modifier = modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )
    } else {
        Text("Không tìm thấy ảnh: $imageName")
    }
}