package com.example.apptravel.ui.screen

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.draw.shadow


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(navController: NavController) {
    val context = LocalContext.current
    val imageBitmap = remember {
        try {
            val inputStream = context.assets.open("images/home_background.png")
            BitmapFactory.decodeStream(inputStream)?.asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Trang chủ",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        fontFamily = FontFamily.SansSerif
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0x88000000),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color.Transparent
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Hình nền
            imageBitmap?.let {
                Image(
                    bitmap = it,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            // Overlay mờ
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
            )

            // Nội dung chính
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Tiêu đề chính
                Text(
                    text = "CHÀO MỪNG BẠN ĐẾN APP DU LỊCH TẠI TP. HỒ CHÍ MINH",
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 34.sp,
                    textAlign = TextAlign.Center,
                    letterSpacing = 1.sp,
                    fontFamily = FontFamily.SansSerif,
                    modifier = Modifier.shadow(4.dp)
                )

                Spacer(modifier = Modifier.height(28.dp))

                // Card mô tả tính năng
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0x55FFFFFF)),
                    elevation = CardDefaults.cardElevation(8.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        FeatureText("• Xem bản đồ các điểm du lịch tại TP.HCM")
                        FeatureText("• Lọc theo loại địa điểm: bảo tàng, khách sạn...")
                        FeatureText("• Hiển thị định vị vị trí người dùng ")
                        FeatureText("• Xem chi tiết mô tả và hình ảnh từng điểm")
                    }
                }

                Spacer(modifier = Modifier.height(36.dp))

                // Nút bắt đầu
                Button(
                    onClick = { navController.navigate("main") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                    modifier = Modifier
                        .height(48.dp)
                        .fillMaxWidth(0.8f)
                ) {
                    Text("Bắt đầu khám phá", fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun FeatureText(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 16.sp,
        lineHeight = 22.sp,
        fontFamily = FontFamily.SansSerif,
        modifier = Modifier.padding(bottom = 6.dp)
    )
}
